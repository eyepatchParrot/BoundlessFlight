function InputManager::onTouchDown( %this, %touchId, %worldPosition )
{
	Player.shoot();
}